#include<iostream>
#include<cmath>
using namespace std;
void diff(int a,int b){
	int c=a-b;
	cout<<"The Differnece of "<<a<<" and "<<b<<" is "<<c<<endl;
}
void sum(int a,int b){
	int c=a+b;
	cout<<"The sum of "<<a<<" and "<<b<<" is "<<c<<endl;
}
void product(int a,int b){
	int c=a*b;
	cout<<"The product of "<<a<<" and "<<b<<" is "<<c<<endl;
}
void quo(int a,int b){
	int c=a/b;
	cout<<"The Quotient of "<<a<<" and "<<b<<" is "<<c<<endl;
}
void sm(int a,int b){
	int c=a+b;
	cout<<"The sum of "<<a<<" and "<<b<<" is "<<c<<endl;
}
void remainder(int a,int b){
	int c=a%b;
	cout<<"The Reminder of "<<a<<" and "<<b<<" is "<<c<<endl;
}
void square(int a,int b){
	cout<<"Square root of "<<a<<" is "<<sqrt(a)<<endl;
	cout<<"Square root of "<<b<<" is "<<sqrt(b)<<endl;
}
void lo(int a, int b){
	cout<<"Log(to base-e) of "<<a<<" is "<<log(a)<<endl;
		cout<<"Log(to base-e) of "<<b<<" is "<<log(b)<<endl;
}
int main(){
	int a,b,c;
	cout<<"Enter 2 numbers ";
	cin>>a>>b;
	while (true){
		cout<<"\n";
   cout<<"1. Press 1 for sum \n 2.Press 2 for difference \n  3.Press 3 for Quotient \n    4.Press 4 for Reminder \n    5.Press 5 for Square \n     6.Press 6 for log"<<endl;
	cin>>c;
	if(c==1){
		sm(a,b);
	}
	else if(c==2){
		diff(a,b);
	}
	else if(c==3){
		quo(a,b);
	}
	else if(c==4){
		remainder(a,b);
	}
	else if(c==5){
		square(a,b);
	}
	else if(c==6){
		lo(a,b);
	}
	else 
	break;
}
return 0;
}
